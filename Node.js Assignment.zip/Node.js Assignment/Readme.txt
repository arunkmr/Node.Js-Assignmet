//create student under postgre sql

-- Table: public.student

-- DROP TABLE IF EXISTS public.student;

CREATE TABLE IF NOT EXISTS public.student
(
    name text COLLATE pg_catalog."default",
    age integer,
    mark1 integer,
    mark2 integer,
    mark3 integer,
    id integer NOT NULL DEFAULT nextval('student_id_seq'::regclass),
    CONSTRAINT student_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.student
    OWNER to postgres;
	
//I have attached the test.csv file to upload student data.	
	
	