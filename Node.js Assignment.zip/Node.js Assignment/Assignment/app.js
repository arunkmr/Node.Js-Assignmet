const express = require('express') //Including express server pkg
const exphbs = require('express-handlebars') //works as template engine
const bodyparser = require('body-parser') //to handling json format data
const multer = require('multer')
const path = require('path')


require('dotenv').config() //to use constant values


const app = express() //obj for exp server
const port = process.env.PORT || 5000

app.use(bodyparser.urlencoded({extended:false})) //middleware
app.use(bodyparser.json())

app.use(express.static('public')) //calling external folder files

const handlebars = exphbs.create({extname:".hbs"}) //calling template engine    
app.engine('hbs', handlebars.engine)
app.set("view engine", "hbs")

//Multer
var storage = multer.diskStorage({
    destination: (req, file, callBack) => {
        callBack(null, './')    
    },
    filename: (req, file, callBack) => {
        callBack(null, file.fieldname + path.extname(file.originalname))
    }
})

var upload = multer({
    storage: storage
});


const routes = require("./server/routes/students")
app.use('/',routes)

//Listen port 
app.listen(port, ()=>{
    console.log('Listening Port'+5000)
})