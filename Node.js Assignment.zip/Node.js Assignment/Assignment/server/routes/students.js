const express = require('express')
const router = express.Router();
const student_controller = require("../controllers/students_controller")
//View all Records
router.get("/",student_controller.view)
router.get("/view",student_controller.view)
//View Pass Records
router.get("/pass",student_controller.pass)
//View Fail Records
router.get("/fail",student_controller.fail)
//Upload function
router.post("/uploadfile",student_controller.uploadfile)
//Search Student
router.get("/search",student_controller.search)
router.post("/search_student",student_controller.search_student)

module.exports = router