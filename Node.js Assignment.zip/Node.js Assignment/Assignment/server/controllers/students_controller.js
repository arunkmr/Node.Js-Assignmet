const express = require('express') 
const pg = require('pg') //to connect postgre sql server
const fs = require('fs');//to file opeations
const csv = require('fast-csv');
const multer = require('multer')
const path = require('path')
const { Pool } = require('pg')
const pool = new Pool()
var fileUpload= require('../middleware/upload-middleware')

const app = express()

const db = new Pool({
    host:"localhost",
    user:"postgres",
    port:5432,
    password:"gspl",
    database:"postgres"
})

exports.view =(req,res)=>{
    //connection check
    db.connect(function (err) {
        if (err) {
            return console.error('error: ' + err.message);
        }
        db.query('select * from student', (err, result)=>{
            if(!err){            
                res.render("home", {result});           
            }
            else{
                console.log(err)
            }
        })  
    })
}


exports.uploadfile =(req,res)=>{
    var upload = multer({
            storage: fileUpload.files.storage(), 
            allowedFile:fileUpload.files.allowedFile 
        }).single('uploadfile');
    upload(req, res, function (err) {
        if (err instanceof multer.MulterError) {
             res.send(err);
        } else if (err) {
            res.send(err);
        }else{
            const { dirname } = require('path');
            const appDir = dirname(require.main.filename);
            UploadCsvDataToPGSQL(appDir + '/public/files/' + req.file.filename);
            console.log('CSV file data has been uploaded in postgre sql database');        
            //res.send(`You have uploaded file successfully`);
            res.render("Thanks"); 
        }
    }) 
}

function UploadCsvDataToPGSQL(filePath){
    console.log(filePath)
    let stream = fs.createReadStream(filePath);
    let csvData = [];
    let csvStream = csv
        .parse()
        .on("data", function (data) {
            csvData.push(data);
        })
        .on("end", function () {
            // Remove Header ROW
            csvData.shift();
            // Open the postgre connection          
            const query ="INSERT INTO student ( name, age, mark1, mark2, mark3) VALUES ($1, $2, $3, $4, $5)";
            
            csvData.forEach(row => {
                db.query(query, row, (err, res) => {
                    if (err) {
                        console.log(err.stack);
                    } else {
                        console.log("inserted " + res.rowCount + " row:", row);
                       
                    }
                });
            });
            fs.unlinkSync(filePath)
            db.end        
        });
    stream.pipe(csvStream);  
}

exports.pass =(req,res)=>{
    //connection check
    db.connect(function (err) {
        if (err) {
            return console.error('error: ' + err.message);
        }
        let id = req.params.id;
        db.query('select * from student where mark1>=35 and mark2>=35 and mark3>=35', (err, result)=>{
            if(!err){            
                res.render("home", {result});           
            }
            else{
                console.log(err)
            }
        })  
    })
}

exports.fail =(req,res)=>{
    //connection check
    db.connect(function (err) {
        if (err) {
            return console.error('error: ' + err.message);
        }
        let id = req.params.id;
        db.query('select * from student where mark1<35 or mark2<35 or mark3<35', (err, result)=>{
            if(!err){            
                res.render("home", {result});           
            }
            else{
                console.log(err)
            }
        })  
    })
}

exports.search =(req,res)=>{
    res.render("search"); 
}

exports.search_student =(req,res)=>{
    //connection check
    db.connect(function (err) {
        if (err) {
            return console.error('error: ' + err.message);
        }
        const {id} = req.body 
        db.query('select * from student where id=$1', [id] ,(err, result)=>{
            if(!err){            
                res.render("search", {result});           
            }
            else{
                console.log(err)
            }
        })  
    })
}

